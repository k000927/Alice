const userService = require("./userService");
const groupService = require("./groupService");
const postService = require("./postService");

module.exports = {
  userService,
  groupService,
  postService,
};
