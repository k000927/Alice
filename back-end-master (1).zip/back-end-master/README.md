hello backend

git clone "copied address"

cd back-end

npm install

git config --global core.autocrlf true